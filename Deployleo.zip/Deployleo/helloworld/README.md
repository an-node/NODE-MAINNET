# Leo helloworld

## Run Guide

To run this program, run:
```bash
leo run main
```

## Execute Guide

To execute this program, run:
```bash
leo execute main
```

## Overview 

This example shows how to sum two u32 numbers.

It takes the input data from inputs/helloworld.in